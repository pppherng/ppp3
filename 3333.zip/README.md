# Information

Advanced Music Bot With Many Filters & Play Support (Youtube, Spotify, Etc)

- Filters (Nightcore, Bassboost, Flanger, 8D, Etc)
- Easy & Free To Use

### Setup

- Download / Export This Repository & Make Sure To Install [Node.js (v12 Or Higher)](https://nodejs.org/en/) & [Visual Studio Code (You Can Use Any Code Editor)](https://code.visualstudio.com/)
- Open Project In Visual Studio Code (Editor) & In Visual Studio Code To Open Console / Terminal - **Ctrl + A**
- In Your Project Console / Terminal Type - **npm i**
- And Wait For Bot Packages To Install...
- After Installing Done, Go To Config.js
- Fill Information & Then Type This Command In Your Console / Terminal - **_node ._** Or **_node index.js_**
- When Bot Is Ready, You Will See A Message In Console / Terminal
- Enjoy <3

### Credits

- Special Thanks To [Github](https://github.com), [Stackoverflow](https://stackoverflow.com), [Node Package Manager](https://www.npmjs.com/), [Google](https://google.com)

### Donate

By Donating, You Will Help Me To Maintain This Bot 💙

- [Paypal](https://www.paypal.com/paypalme/legendemoji)
- [Patreon](https://www.patreon.com/LegendaryEmoji)
- [Ko-Fi](https://ko-fi.com/LegendaryEmoji)

### Other

- Author - Legendary Emoji#1742
- Support - [Click Me](https://discord.gg/umMpnqS)
- License - [MIT](https://github.com/LegendaryEmoji/Music-Bot/blob/main/LICENSE)