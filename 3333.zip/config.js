/* Your Bot Default Prefix For Every Server */
exports.Default_Prefix = "/";
/* Your Bot All Embeds Color */
exports.Color = "RANDOM";
/* Your Bot Token (Secret) */
exports.Token = "ODEyMTg3OTY3MDY1MjkyODEw.YC9G_Q.mfQZyyZlvmkHb6r8DDPm7-Ited8"

